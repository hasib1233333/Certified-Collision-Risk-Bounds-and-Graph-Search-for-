Supplementary Material: code, data and raw results

Run ./reproduce.sh (Python 3.13; pip install -r requirements.txt).
Outputs (tables, figures, numbers*.tex) are written to ../CMC_LaTeX_submission/.
results_*.jsonl: raw per-plan results used in the paper.
data/willow-full-0.05.pgm: Willow Garage map, ROS navigation_tutorials (BSD license).

GitHub: https://github.com/hasib1233333/Certified-Collision-Risk-Bounds-and-Graph-Search-for-.git
