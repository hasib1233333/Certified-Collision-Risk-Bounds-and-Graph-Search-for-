"""Analysis of the Willow Garage real-map benchmark: table, macros, example figure."""
import json, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.special import ndtri
from scipy.stats import beta, binomtest
import run_willow as RW
from acp import *
OUT = "../CMC_LaTeX_submission/"
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Liberation Sans", "Arial", "Helvetica", "DejaVu Sans"],
                     "font.size": 8, "axes.linewidth": 0.6, "lines.linewidth": 1.0, "lines.markersize": 3.5,
                     "legend.fontsize": 8, "legend.frameon": False, "xtick.direction": "in", "ytick.direction": "in",
                     "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black", "text.color": "black",
                     "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
                     "mathtext.bf": "Liberation Sans:bold", "mathtext.cal": "Liberation Sans:italic", "pdf.fonttype": 42})
PANEL = lambda ax, k: ax.text(-0.1, 1.06, "ABCDEF"[k], transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")
DIG = dict(zip("0123456789", ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]))
macros = {}
mac = lambda k, v: macros.__setitem__("".join(DIG.get(c, c) for c in k.replace(".", "")), v)
NAME = dict(THR50="THR-0.5", THRd=r"THR-$\delta$", BOOLE="Boole", IND="IND", PB="ACP-PB", CHAIN="ACP-CH")


def sci(x, d=2):
    if x == 0: return "0"
    e = int(np.floor(np.log10(abs(x)))); m = x / 10 ** e
    return f"{x:.{d}f}" if e == 0 else rf"{m:.{d}f}\times10^{{{e}}}"


D = pd.read_json("results_willow.jsonl", lines=True)
D["viol"] = D.mc > D.delta + 3 * np.sqrt(D.delta * (1 - D.delta) / 1e4)
mac("wN", str(D.inst.nunique())); mac("wplans", f"{len(D):,}".replace(",", "{,}"))
rows = []
for ker, ell in RW.SETTINGS:
    for m in RW.METHODS:
        s = D[(D.ker == ker) & (D.ell == ell) & (D.method == m)]
        sf = s[s.feasible]
        rows.append(rf"{'SE' if ker == 'se' else 'CAR'}, $\ell={ell:g}$ & {NAME[m]} & {100 * s.feasible.mean():.1f} & "
                    rf"{int(sf.viol.sum())}/{len(sf)} & ${sci(sf.mc.mean())}$ & {sf.L.mean():.1f}\\")
    rows.append(r"\midrule")
open(OUT + "tab_willow.tex", "w").write("\n".join(rows[:-1]))
cert = D[D.method.isin(["BOOLE", "IND", "PB", "CHAIN"]) & D.feasible & ((D.ker == "car") | (D.method != "CHAIN"))]
mac("wcertviol", str(int(cert.viol.sum()))); mac("wcertn", str(len(cert)))
k, n = int(cert.viol.sum()), len(cert)
mac("wcertcpu", sci(beta.ppf(0.975, k + 1, n - k)))
ch = D[(D.method == "CHAIN") & D.feasible & (D.ker == "se")]
mac("wchseviol", str(int(ch.viol.sum()))); mac("wchsen", str(len(ch)))
for m in ["THR50", "THRd"]:
    s = D[(D.method == m) & D.feasible]
    mac(f"wviolrate{m}", f"{100 * s.viol.mean():.1f}")
for m in ["IND", "PB", "CHAIN"]:
    mac(f"wfeas{m}", f"{100 * D[D.method == m].feasible.mean():.1f}")
P = D.pivot_table(index=["inst", "ker", "ell", "delta"], columns="method", values="feasible", aggfunc="first").astype(bool)
for a in ["PB", "CHAIN"]:
    n10, n01 = int((P[a] & ~P["IND"]).sum()), int((~P[a] & P["IND"]).sum())
    pv = binomtest(n10, n10 + n01, 0.5).pvalue if n10 + n01 else 1.0
    mac(f"wflip{a}", f"{n10}/{n01}"); mac(f"wflipp{a}", "<0.001" if pv < 1e-3 else f"{pv:.3f}")
print(macros)
with open(OUT + "numbers_willow.tex", "w") as f:
    for kk, v in macros.items():
        f.write(rf"\newcommand{{\{kk}}}{{{v}}}" + "\n")

# ---- example: instance where IND is infeasible but ACP-CH (CAR) or ACP-PB (SE) is feasible
inst = json.load(open("willow_instances.json"))
sub = D[(D.ker == "se") & (D.ell == 4.0) & (D.delta == 0.10)].pivot(index="inst", columns="method", values="feasible").astype(bool)
cand = sub[~sub["IND"] & sub["PB"]].index.tolist() or sub[sub["IND"]].index.tolist()
kk = int(cand[0]); i, j, s, g = inst[kk]
W = RW.W
M = MapModel(ndtri(RW.P[i:i + W, j:j + W]), 1.0, GRF(W, 4.0))
fig = plt.figure(figsize=(5.7, 3.3))
ax0 = fig.add_axes([0.0, 0.2, 0.46, 0.78]); ax1 = fig.add_axes([0.5, 0.2, 0.42, 0.78])
ax0.imshow(np.log10(RW.P), cmap="Greys", vmin=-4, vmax=0, interpolation="nearest")
ax0.add_patch(plt.Rectangle((j - 0.5, i - 0.5), W, W, fill=False, ec="w", lw=3.0))
ax0.add_patch(plt.Rectangle((j - 0.5, i - 0.5), W, W, fill=False, ec="k", lw=1.3, ls="--"))
ax0.set_xticks([]); ax0.set_yticks([]); PANEL(ax0, 0)
im = ax1.imshow(np.log10(M.p), cmap="Greys", vmin=-4, vmax=0, interpolation="nearest")
st = dict(THR50=(":", "0.0", 1.4), IND=("--", "0.0", 1.0), PB=("-", "0.45", 1.6), CHAIN=("-", "0.0", 1.0))
paths = []
for m in ["THR50", "IND", "PB", "CHAIN"]:
    r, _ = plan(M, m, s, g, 0.10); paths.append(None if r is None else r["cells"])
mc = mc_risk(M, paths, 20000, np.random.default_rng(3))
for m, c, x in zip(["THR50", "IND", "PB", "CHAIN"], paths, mc):
    if c is None:
        ax1.plot([], [], color="w", label=f"{NAME[m]}: infeasible"); continue
    rr, cc = c // W, c % W
    Lm = np.hypot(np.diff(rr), np.diff(cc)).sum()
    ax1.plot(cc, rr, ls=st[m][0], color=st[m][1], lw=st[m][2], label=f"{NAME[m]}: $L$={Lm:.1f}, $\\mathcal{{R}}$=${sci(x)}$")
ax1.plot(s % W, s // W, "ks", ms=4); ax1.plot(g % W, g // W, "k*", ms=6)
ax1.set_xticks([]); ax1.set_yticks([]); PANEL(ax1, 1)
cax = fig.add_axes([0.93, 0.2, 0.015, 0.78]); cb = fig.colorbar(im, cax=cax); cb.set_label(r"$\log_{10} p_i$")
h, l = ax1.get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=2, frameon=False, bbox_to_anchor=(0.5, 0.0))
fig.savefig(OUT + "figs/fig_willow.pdf", bbox_inches="tight")
print("example", kk, [(m, None if c is None else round(float(x), 4)) for m, c, x in zip(["THR50", "IND", "PB", "CHAIN"], paths, mc)])
