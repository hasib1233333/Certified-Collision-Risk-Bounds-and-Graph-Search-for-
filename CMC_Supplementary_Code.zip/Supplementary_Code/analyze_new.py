"""Analysis of the revision experiments: calibration / prior misspecification (GMRF), footprint, scalability."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import beta, norm
OUT = "../CMC_LaTeX_submission/"
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Liberation Sans", "Arial", "Helvetica", "DejaVu Sans"],
                     "font.size": 8, "axes.linewidth": 0.6, "lines.linewidth": 1.0, "lines.markersize": 3.5,
                     "legend.fontsize": 8, "legend.frameon": False, "xtick.direction": "in", "ytick.direction": "in",
                     "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
                     "mathtext.bf": "Liberation Sans:bold", "mathtext.cal": "Liberation Sans:italic", "pdf.fonttype": 42})
PANEL = lambda ax, k: ax.text(-0.12, 1.06, "ABCDEF"[k], transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")
DIG = dict(zip("0123456789", ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]))
macros = {}
mac = lambda k, v: macros.__setitem__("".join(DIG.get(c, c) for c in k.replace(".", "")), v)
NAME = dict(THR50="THR-0.5", THRd=r"THR-$\delta$", BOOLE="Boole", IND="IND", PB="ACP-PB", CHAIN="ACP-CH",
            THRinf="THR-inflated", INDpt="IND (point robot)", INDfp="IND-fp", PBfp="ACP-PB-fp", CHfp="ACP-CH-fp")


def sci(x, d=2):
    if x == 0: return "0"
    e = int(np.floor(np.log10(abs(x)))); m = x / 10 ** e
    return f"{x:.{d}f}" if e == 0 else rf"{m:.{d}f}\times10^{{{e}}}"


def cp(k, n):
    lo = 0.0 if k == 0 else beta.ppf(0.025, k, n - k + 1)
    hi = 1.0 if k == n else beta.ppf(0.975, k + 1, n - k)
    return lo, hi


# =============================================================== 1. calibration / misspecification
frames = []
for w, f in [(0.35, "results_gmrf.jsonl"), (0.7, "results_gmrf_w07.jsonl"), (1.0, "results_gmrf_w10.jsonl")]:
    d = pd.read_json(f, lines=True); d["w"] = w; frames.append(d)
G = pd.concat(frames)
G["viol"] = G.mc > G.delta + 3 * np.sqrt(G.delta * (1 - G.delta) / 6000)
CERT = ["BOOLE", "IND", "PB", "CHAIN"]
rows = []
for w in [0.35, 0.7, 1.0]:
    for grp, ms in [("certified", CERT), ("THR-0.5", ["THR50"])]:
        s = G[(G.w == w) & G.method.isin(ms) & G.feasible]
        k, n = int(s.real_collision.sum()), len(s)
        lo, hi = cp(k, n)
        pred = s.mc.mean()
        # z-test of realised collisions against the Poisson-binomial implied by the predicted (Bayesian) risks
        g = s.assign(k=s.real_collision.astype(float)).groupby(["fam", "seed"]).agg(k=("k", "sum"), e=("mc", "sum"))
        z = (g.k - g.e).sum() / np.sqrt(((g.k - g.e) ** 2).sum())  # cluster-robust (paths on one map share a world)
        rows.append(dict(w=w, grp=grp, n=n, pred=pred, real=k / n, lo=lo, hi=hi, z=z, viol=int(s.viol.sum())))
C = pd.DataFrame(rows); print(C.round(4))
lines = []
for _, r in C.iterrows():
    lab = {0.35: "0.35 (misspecified)", 0.7: "0.70 (misspecified)", 1.0: "1.00 (correct)"}[r.w]
    lines.append(rf"{lab} & {r.grp} & {r.n} & ${sci(r.pred)}$ & ${sci(r.real)}$ & $[{sci(r.lo)},\,{sci(r.hi)}]$ & {r.z:+.2f} & {r.viol}\\")
open(OUT + "tab_calib.tex", "w").write("\n".join(lines))
for _, r in C[C.grp == "certified"].iterrows():
    t = {0.35: "a", 0.7: "b", 1.0: "c"}[r.w]
    mac(f"cal{t}pred", sci(r.pred)); mac(f"cal{t}real", sci(r.real)); mac(f"cal{t}z", f"{r.z:.2f}")
    mac(f"cal{t}lo", sci(r.lo)); mac(f"cal{t}hi", sci(r.hi)); mac(f"cal{t}n", str(r.n)); mac(f"cal{t}viol", str(r.viol))
# reliability diagram
fig, ax = plt.subplots(1, 2, figsize=(6.4, 2.8))
bins = np.array([0, 0.01, 0.03, 0.06, 0.1, 0.2, 1.0])
for j, grp in enumerate([CERT, ["THR50"]]):
    for w, mk, col in [(0.35, "s", "0.65"), (0.7, "o", "0.4"), (1.0, "D", "0.0")]:
        s = G[(G.w == w) & G.method.isin(grp) & G.feasible]
        idx = np.digitize(s.mc, bins) - 1
        xs, ys, es = [], [], []
        for b in range(len(bins) - 1):
            ss = s[idx == b]
            if len(ss) < 10: continue
            k = int(ss.real_collision.sum()); lo, hi = cp(k, len(ss))
            xs.append(ss.mc.mean()); ys.append(k / len(ss)); es.append((k / len(ss) - lo, hi - k / len(ss)))
        es = np.array(es).T
        ax[j].errorbar(xs, ys, yerr=es, marker=mk, color=col, mfc="white" if w < 1 else col, capsize=2, lw=0.8,
                       label=f"prior weight $w={w:g}$" + (" (correct)" if w == 1 else ""))
    lim = (0, 0.6 if j == 0 else 1.0)
    ax[j].plot(lim, lim, "k:", lw=0.7, label="perfect calibration")
    ax[j].set_xlim(lim); ax[j].set_ylim(lim); ax[j].grid(alpha=0.25, lw=0.4)
    ax[j].set_xlabel("Predicted (Bayesian) collision probability")
    PANEL(ax[j], j)
ax[0].set_ylabel("Realized collision frequency")
fig.tight_layout(rect=(0, 0.12, 1, 1))
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=4, bbox_to_anchor=(0.5, 0.0))
fig.savefig(OUT + "figs/fig_calib.pdf", bbox_inches="tight"); plt.close(fig)

# =============================================================== 2. footprint
F = pd.read_json("results_footprint.jsonl", lines=True)
F["viol"] = F.mc > F.delta + 3 * np.sqrt(F.delta * (1 - F.delta) / 1e4)
M5 = ["THRinf", "INDpt", "INDfp", "PBfp", "CHfp"]
lines = []
for m in M5:
    row = [NAME[m]]
    for k, l in [("se", 4.0), ("car", 64.0)]:
        s = F[(F.method == m) & (F.ker == k)]
        sf = s[s.feasible]
        row += [f"{100 * s.feasible.mean():.1f}", f"{int(sf.viol.sum())}/{len(sf)}",
                f"${sci(sf.mc.mean())}$" if len(sf) else "--", f"{sf.L.mean():.1f}" if len(sf) else "--"]
    lines.append(" & ".join(row) + r"\\")
open(OUT + "tab_fp.tex", "w").write("\n".join(lines))
for m in M5:
    for k in ["se", "car"]:
        s = F[(F.method == m) & (F.ker == k)]; sf = s[s.feasible]
        mac(f"fp{m}{k}feas", f"{100 * s.feasible.mean():.1f}"); mac(f"fp{m}{k}v", str(int(sf.viol.sum()))); mac(f"fp{m}{k}n", str(len(sf)))
        mac(f"fp{m}{k}vr", f"{100 * sf.viol.mean():.1f}" if len(sf) else "0")
# certificate validity per path (certified regimes)
cv = F[F.feasible & F.method.isin(["INDfp", "PBfp", "CHfp"])]
ok = cv[(cv.method != "CHfp") | (cv.ker == "car")]
under = (ok.certR < ok.mc - 3 * np.sqrt(ok.mc * (1 - ok.mc) / 1e4)).sum()
mac("fpcertn", str(len(ok))); mac("fpunder", str(int(under)))
k_, n_ = int(ok.viol.sum()), len(ok); mac("fpcertviol", str(k_)); mac("fpcertcpu", sci(beta.ppf(0.975, k_ + 1, n_ - k_)))
print(F.groupby(["ker", "method"]).agg(f=("feasible", "mean"), v=("viol", "sum"), mc=("mc", "mean")).round(4))

# =============================================================== 3. scalability
S = pd.read_json("results_scale2.jsonl", lines=True)
T = S.groupby(["n", "method"]).agg(t=("time", "median"), b=("build", "median"), mem=("rss_peak_mb", "median"),
                                    it=("iters", "mean"), f=("feasible", "mean")).reset_index()
print(T.round(3))
lines = []
for n in sorted(S.n.unique()):
    r = T[T.n == n].set_index("method")
    lines.append(rf"${n}\times{n}$ & {n * n:,} & {1000 * r.b.mean():.0f} & ".replace(",", "{,}") +
                 " & ".join(f"{1000 * r.loc[m, 't']:.0f}" for m in ["BOOLE", "IND", "PB", "CHAIN"]) + " & " +
                 " & ".join(f"{r.loc[m, 'mem']:.0f}" for m in ["IND", "PB", "CHAIN"]) + r"\\")
open(OUT + "tab_scale.tex", "w").write("\n".join(lines))
for n in sorted(S.n.unique()):
    r = T[T.n == n].set_index("method")
    for m in ["BOOLE", "IND", "PB", "CHAIN"]:
        mac(f"st{m}{n}", f"{1000 * r.loc[m, 't']:.0f}"); mac(f"sm{m}{n}", f"{r.loc[m, 'mem']:.0f}")
    mac(f"sb{n}", f"{1000 * r.b.mean():.0f}")
mac("scalemaps", str(S.seed.nunique()))
fig, ax = plt.subplots(1, 2, figsize=(6.4, 2.7))
mk = dict(BOOLE=("s", "0.6"), IND=("o", "0.4"), PB=("^", "0.15"), CHAIN=("D", "0.0"))
nn = sorted(S.n.unique())
for m in ["BOOLE", "IND", "PB", "CHAIN"]:
    r = T[T.method == m].sort_values("n")
    ax[0].plot(r.n ** 2, 1000 * r.t, marker=mk[m][0], color=mk[m][1], label=NAME[m])
    ax[1].plot(r.n ** 2, r.mem, marker=mk[m][0], color=mk[m][1])
b = T.groupby("n").b.mean()
ax[0].plot(np.array(nn) ** 2, 1000 * b.values, "k:", marker="x", label="cost construction")
for a_ in ax:
    a_.set_xscale("log"); a_.set_yscale("log"); a_.set_xticks([x * x for x in nn])
    a_.set_xticklabels([f"${x}^2$" for x in nn]); a_.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
    a_.set_xlabel(r"Grid size (cells)"); a_.grid(alpha=0.25, lw=0.4, which="both")
ax[0].set_ylabel("Median time (ms)"); ax[1].set_ylabel("Peak resident memory (MB)")
PANEL(ax[0], 0); PANEL(ax[1], 1)
fig.tight_layout(rect=(0, 0.12, 1, 1))
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=5, bbox_to_anchor=(0.5, 0.0))
fig.savefig(OUT + "figs/fig_scale.pdf", bbox_inches="tight"); plt.close(fig)

with open(OUT + "numbers_new.tex", "w") as f:
    for k, v in macros.items():
        f.write(rf"\newcommand{{\{k}}}{{{v}}}" + "\n")
print(macros)
