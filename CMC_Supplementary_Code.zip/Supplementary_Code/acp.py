"""
Association-Certified Planning (ACP) on spatially correlated probabilistic occupancy maps.

Core library:
  * stationary Gaussian random field (GRF) sampler via circulant embedding
  * exact bivariate normal CDF via Owen's T function
  * risk models: BOOLE, IND, CHAIN (uncertified), PB (pair-block, certified), PB-FIX (fixed alignment)
  * lifted-graph construction and LARAC constrained shortest path on scipy csgraph
  * Monte-Carlo ground-truth path risk
"""
import numpy as np
from scipy.special import owens_t, ndtr, log_ndtr
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra

SQ2 = np.sqrt(2.0)
DIRS = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


# ----------------------------------------------------------------------------- GRF
class GRF:
    """Unit-variance stationary GRF on an n x n crop of a P x P torus."""

    def __init__(self, n, ell, kernel="se", pad=None, omega=0.0):
        self.n = n
        if ell <= 0:
            self.indep = True
            self.c = None
            return
        self.indep = False
        P = pad or (2 * n if kernel == "car" else int(2 ** np.ceil(np.log2(n + 8 * ell))))
        self.P = P
        d = np.minimum(np.arange(P), P - np.arange(P)).astype(float)
        D2 = d[:, None] ** 2 + d[None, :] ** 2
        if kernel == "se":
            base = np.exp(-D2 / (2 * ell ** 2))
        elif kernel == "dcos":  # damped cosine: has negative lobes (association fails)
            base = np.exp(-D2 / (2 * ell ** 2)) * np.cos(omega * np.sqrt(D2))
        elif kernel == "car":  # GMRF, precision Q = kappa^2 I + graph Laplacian (M-matrix => MTP2)
            base = None
        else:
            raise ValueError(kernel)
        if kernel == "car":
            k = np.arange(P)
            s2 = 4 * np.sin(np.pi * k / P) ** 2
            lam = 1.0 / ((1.0 / ell) ** 2 + s2[:, None] + s2[None, :])
        else:
            lam = np.real(np.fft.fft2(base))
        self.neg_mass = float(-lam[lam < 0].sum() / np.abs(lam).sum())
        lam = np.clip(lam, 0, None)
        ceff = np.real(np.fft.ifft2(lam))
        self.scale = 1.0 / np.sqrt(ceff[0, 0])
        self.c = ceff / ceff[0, 0]  # exact covariance of the sampled field
        self.sqrt_lam = np.sqrt(lam / (P * P))

    def rho(self, di, dj):
        if self.indep:
            return 0.0
        return float(self.c[di % self.P, dj % self.P])

    def min_cov_in_crop(self):
        if self.indep:
            return 0.0
        n = self.n
        return float(self.c[:n, :n].min())

    def sample(self, m, rng):
        """Return m samples of shape (m, n, n)."""
        n = self.n
        if self.indep:
            return rng.standard_normal((m, n, n))
        out = np.empty((m, n, n))
        k = 0
        while k < m:
            z = rng.standard_normal((self.P, self.P)) + 1j * rng.standard_normal((self.P, self.P))
            f = np.fft.fft2(self.sqrt_lam * z) * self.scale
            out[k] = f.real[:n, :n]
            k += 1
            if k < m:
                out[k] = f.imag[:n, :n]
                k += 1
        return out


# ----------------------------------------------------------------------------- BVN
def bvn_cdf(h, k, rho):
    """P(X<=h, Y<=k) for standard bivariate normal with correlation rho (vectorised, exact via Owen's T)."""
    h = np.asarray(h, float).copy()
    k = np.asarray(k, float).copy()
    rho = np.broadcast_to(np.asarray(rho, float), h.shape).copy()
    eps = 1e-12
    h[np.abs(h) < eps] = eps
    k[np.abs(k) < eps] = eps * 1.37
    s = np.sqrt(np.maximum(1 - rho ** 2, 1e-300))
    ah = (k - rho * h) / (h * s)
    ak = (h - rho * k) / (k * s)
    beta = np.where(h * k < 0, 0.5, 0.0)
    val = 0.5 * ndtr(h) + 0.5 * ndtr(k) - owens_t(h, ah) - owens_t(k, ak) - beta
    lo = np.maximum(ndtr(h) + ndtr(k) - 1, 0.0)
    hi = np.minimum(ndtr(h), ndtr(k))
    return np.clip(val, lo, hi)


# ----------------------------------------------------------------------------- map quantities
class MapModel:
    """Latent field Z = m + sigma*eps, cell occupied iff Z>0. Free iff eps <= t, t=-m/sigma."""

    def __init__(self, mean, sigma, grf_true=None, grf_plan=None, corr=None, sampler=None):
        self.mean = mean
        self.n = mean.shape[0]
        self.t = -mean / sigma
        self.p = ndtr(-self.t)  # occupancy probability
        self.logP1 = log_ndtr(self.t)  # log P(free)
        self.grf_true = grf_true
        self.grf_plan = grf_plan or grf_true
        if corr is None:  # stationary: correlation depends on the offset only
            corr = lambda u, v, di, dj: np.full(np.shape(u), self.grf_plan.rho(di, dj))
        self.corr = corr
        self.sampler = sampler or (lambda m, rng: self.grf_true.sample(m, rng))
        self._edges()

    def _edges(self):
        n = self.n
        I, J = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
        src, dst, ln, lp2 = [], [], [], []
        for di, dj in DIRS:
            ok = (I + di >= 0) & (I + di < n) & (J + dj >= 0) & (J + dj < n)
            u = (I * n + J)[ok]
            v = ((I + di) * n + (J + dj))[ok]
            r = self.corr(u, v, di, dj)
            tu, tv = self.t.ravel()[u], self.t.ravel()[v]
            p2 = bvn_cdf(tu, tv, r) if np.any(r != 0) else ndtr(tu) * ndtr(tv)
            src.append(u); dst.append(v)
            ln.append(np.full(u.shape, SQ2 if di and dj else 1.0))
            lp2.append(np.log(np.maximum(p2, 1e-300)))
        self.u = np.concatenate(src); self.v = np.concatenate(dst)
        self.L = np.concatenate(ln); self.logP2 = np.concatenate(lp2)
        lp1 = self.logP1.ravel()
        # conditional -log P(v free | u free) >= 0 when rho>=0 (clip tiny negatives from rounding)
        self.r_cond = np.maximum(-(self.logP2 - lp1[self.u]), 0.0)
        self.r_single = -lp1[self.v]


# ----------------------------------------------------------------------------- graphs
class Graph:
    """A (possibly lifted) graph with per-edge length L and risk-cost R, start cost r0, goal states."""

    def __init__(self, nn, s, d, L, R, src, goals, r0, rmax, cell_of):
        self.nn, self.s, self.d, self.L, self.R = nn, s, d, L, R
        self.src, self.goals, self.r0, self.rmax = src, goals, r0, rmax
        self.cell_of = cell_of
        self.A = csr_matrix((np.ones_like(L), (s, d)), shape=(nn, nn))
        # map COO order -> CSR data order
        order = np.lexsort((d, s))
        self.order = order
        self.A.sort_indices()

    def solve(self, lam_L, lam_R):
        # explicit zero weights are kept as edges by scipy.sparse.csgraph (structure is fixed)
        w = lam_L * self.L + lam_R * self.R
        A = self.A.copy()
        A.data = w[self.order]
        dist, pred = dijkstra(A, directed=True, indices=self.src, return_predecessors=True)
        g = self.goals[np.argmin(dist[self.goals])]
        if not np.isfinite(dist[g]):
            return None
        path = [g]
        while path[-1] != self.src:
            path.append(pred[path[-1]])
        path = path[::-1]
        return self._eval(path)

    def _eval(self, path):
        path = np.asarray(path, dtype=np.int64)
        e = self._edge_index(path[:-1], path[1:])
        return dict(states=path, cells=self.cell_of(path), L=float(self.L[e].sum()), R=float(self.R[e].sum()) + self.r0)

    def _edge_index(self, a, b):
        """Vectorised arc lookup: arcs are unique (s, d) pairs; search in the sorted key array."""
        if not hasattr(self, "_keys"):
            k = self.s.astype(np.int64) * self.nn + self.d.astype(np.int64)
            self._ord = np.argsort(k, kind="stable"); self._keys = k[self._ord]
        q = np.asarray(a, np.int64) * self.nn + np.asarray(b, np.int64)
        return self._ord[np.searchsorted(self._keys, q)]


def larac(G, max_iter=40):
    """LARAC (Juttner et al., 2001) for min L s.t. R <= rmax.
    Returns (path or None, iterations, Lagrangian lower bound on the optimal constrained length)."""
    pc = G.solve(1.0, 0.0)
    if pc["R"] <= G.rmax + 1e-12:
        pc["LB"] = pc["L"]
        return pc, 1
    pw = G.solve(0.0, 1.0)  # exact minimum-risk path: decides feasibility exactly (no tie-break term)
    if pw["R"] > G.rmax + 1e-12:
        return None, 2
    pd = G.solve(1e-9, 1.0)  # tie-broken start (shorter among near-minimum-risk paths)
    if pd["R"] > G.rmax + 1e-12:
        pd = pw  # fallback keeps the LARAC invariant: pd is feasible
    it, lb = 3, pc["L"]
    while it < max_iter:
        lam = (pc["L"] - pd["L"]) / (pd["R"] - pc["R"])
        r = G.solve(1.0, lam)
        it += 1
        lb = max(lb, r["L"] + lam * (r["R"] - G.rmax))  # weak duality
        fr = r["L"] + lam * r["R"]
        fc = pc["L"] + lam * pc["R"]
        if abs(fr - fc) < 1e-9 * max(1.0, abs(fc)):
            break
        if r["R"] <= G.rmax + 1e-12:
            pd = r
        else:
            pc = r
    pd["LB"] = lb
    return pd, it


def build_graph(M, method, s_cell, g_cell, delta):
    n2 = M.n * M.n
    u, v, L = M.u, M.v, M.L
    lp1 = M.logP1.ravel()
    ident = lambda path: np.asarray(path) % n2
    if method in ("IND", "BOOLE", "CHAIN", "THR50", "THRd"):
        if method == "IND":
            R, r0, rmax = M.r_single, -lp1[s_cell], -np.log1p(-delta)
        elif method == "BOOLE":
            pv = M.p.ravel()
            R, r0, rmax = pv[v], pv[s_cell], delta
        elif method == "CHAIN":
            R, r0, rmax = M.r_cond, -lp1[s_cell], -np.log1p(-delta)
        else:
            R, r0, rmax = np.zeros_like(L), 0.0, np.inf
        uu, vv, LL, RR = u, v, L, R
        if method in ("THR50", "THRd"):
            okc = M.p.ravel() <= (0.5 if method == "THR50" else delta)
            keep = okc[u] & okc[v]
            uu, vv, LL, RR = u[keep], v[keep], L[keep], R[keep]
        return Graph(n2, uu, vv, LL, RR, s_cell, np.array([g_cell]), r0, rmax, ident)
    # lifted pair-block graph: state 0 = closed (last cell completed its block), 1 = open
    if method not in ("PB", "PBFIX"):
        raise ValueError(method)
    C, O = 0, n2
    ss = [u + C, u + O]
    dd = [v + O, v + C]
    LL = [L, L]
    RR = [M.r_single, M.r_cond]
    if method == "PB":  # allow closing the open cell as a singleton block
        ss.append(u + O); dd.append(v + O); LL.append(L); RR.append(M.r_single)
    S, D = np.concatenate(ss), np.concatenate(dd)
    return Graph(2 * n2, S, D, np.concatenate(LL), np.concatenate(RR), s_cell + O,
                 np.array([g_cell + C, g_cell + O]), -lp1[s_cell], -np.log1p(-delta), ident)


def plan(M, method, s_cell, g_cell, delta):
    G = build_graph(M, method, s_cell, g_cell, delta)
    if method in ("THR50", "THRd"):
        r = G.solve(1.0, 0.0)
        return r, 1
    return larac(G)


# ----------------------------------------------------------------------------- certificates on a given cell path
def certificates(M, cells):
    """Return dict of survival lower bounds / estimates for a fixed cell path."""
    cells = np.asarray(cells)
    lp1 = M.logP1.ravel()
    t = M.t.ravel()
    ind = lp1[cells].sum()
    boole = 1.0 - M.p.ravel()[cells].sum()
    # pair terms along path
    n = M.n
    a, b = cells[:-1], cells[1:]
    di, dj = b // n - a // n, b % n - a % n
    rho = np.array([M.corr(np.array([x0]), np.array([y0]), x, y)[0] for x0, y0, x, y in zip(a, b, di, dj)])
    lp2 = np.log(np.maximum(bvn_cdf(t[a], t[b], rho), 1e-300))
    chain = lp1[cells[0]] + (lp2 - lp1[a]).sum()
    # best consecutive pair/singleton partition by DP (weighted interval matching)
    K = len(cells)
    best = np.full(K + 1, -np.inf); best[0] = 0.0
    for i in range(1, K + 1):
        best[i] = best[i - 1] + lp1[cells[i - 1]]
        if i >= 2:
            best[i] = max(best[i], best[i - 2] + lp2[i - 2])
    return dict(IND=np.exp(ind), BOOLE=max(boole, 0.0), CHAIN=np.exp(chain), PB=np.exp(best[K]))


def mc_risk(M, cell_paths, n_samples, rng, batch=2000):
    """Monte-Carlo collision probability (any traversed cell occupied) under the TRUE field."""
    t = M.t.ravel()
    hits = np.zeros(len(cell_paths))
    done = 0
    while done < n_samples:
        m = min(batch, n_samples - done)
        E = M.sampler(m, rng).reshape(m, -1)
        for k, cp in enumerate(cell_paths):
            if cp is None:
                continue
            cu = np.unique(cp)
            hits[k] += np.any(E[:, cu] > t[cu], axis=1).sum()
        done += m
    return hits / n_samples
