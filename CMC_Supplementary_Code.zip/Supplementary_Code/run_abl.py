"""Ablations: (a) covariance mis-specification, (b) negative-correlation stress test, (c) scaling."""
import numpy as np, json, time
from multiprocessing import Pool
from acp import *
from maps import FAMILIES

DELTA = 0.10
NMC = 10000


def corners(n):
    return 2 * n + 2, (n - 3) * n + (n - 3)


def job_mis(arg):
    fam, seed, ell_plan = arg
    n = 64; s, g = corners(n)
    gt = GRF(n, 2.0); gp = GRF(n, ell_plan)
    M = MapModel(FAMILIES[fam](n, np.random.default_rng(seed)), 1.0, gt, gp)
    recs, paths = [], []
    for m in ["IND", "PB", "CHAIN"]:
        r, _ = plan(M, m, s, g, DELTA)
        recs.append(dict(exp="mis", fam=fam, seed=seed, ell_plan=ell_plan, method=m, feasible=r is not None,
                         L=None if r is None else r["L"]))
        paths.append(None if r is None else r["cells"])
    tr = mc_risk(M, paths, NMC, np.random.default_rng(seed + 777))
    for rec, x in zip(recs, tr):
        rec["mc"] = float(x) if rec["feasible"] else None
    return recs


def job_neg(arg):
    fam, seed = arg
    n = 64; s, g = corners(n)
    gr = GRF(n, 3.0, kernel="dcos", omega=np.pi / 3)
    M = MapModel(FAMILIES[fam](n, np.random.default_rng(seed)), 1.0, gr)
    recs, paths = [], []
    for m in ["BOOLE", "IND", "PB", "CHAIN"]:
        r, _ = plan(M, m, s, g, DELTA)
        rec = dict(exp="neg", fam=fam, seed=seed, method=m, feasible=r is not None,
                   mincov=gr.min_cov_in_crop(), negmass=gr.neg_mass)
        if r is not None:
            rec.update({"cert_" + k: v for k, v in certificates(M, r["cells"]).items()})
        recs.append(rec); paths.append(None if r is None else r["cells"])
    tr = mc_risk(M, paths, NMC, np.random.default_rng(seed + 999))
    for rec, x in zip(recs, tr):
        rec["mc"] = float(x) if rec["feasible"] else None
    return recs


def job_scale(arg):
    n, seed = arg
    s, g = corners(n)
    t0 = time.perf_counter()
    M = MapModel(FAMILIES["clutter"](n, np.random.default_rng(seed)), 1.0, GRF(n, 2.0))
    tb = time.perf_counter() - t0
    recs = []
    for m in ["BOOLE", "IND", "PB", "CHAIN"]:
        t0 = time.perf_counter(); r, it = plan(M, m, s, g, DELTA); dt = time.perf_counter() - t0
        recs.append(dict(exp="scale", n=n, seed=seed, method=m, time=dt, build=tb, iters=it,
                         feasible=r is not None))
    return recs


if __name__ == "__main__":
    out = open("results_abl.jsonl", "w")
    with Pool(2) as P:
        A = [(f, s, lp) for f in FAMILIES for s in range(40) for lp in (1.0, 1.5, 2.0, 3.0, 4.0)]
        for recs in P.imap_unordered(job_mis, A, chunksize=4):
            for r in recs: out.write(json.dumps(r, default=float) + "\n")
        print("mis done", time.strftime("%X"), flush=True)
        B = [(f, s) for f in FAMILIES for s in range(40)]
        for recs in P.imap_unordered(job_neg, B, chunksize=4):
            for r in recs: out.write(json.dumps(r, default=float) + "\n")
        print("neg done", time.strftime("%X"), flush=True)
    for n in (64, 128, 256):  # timing serially, no contention
        for s in range(5):
            for r in job_scale((n, s)): out.write(json.dumps(r, default=float) + "\n")
    print("scale done", time.strftime("%X"), flush=True)
    out.close()
