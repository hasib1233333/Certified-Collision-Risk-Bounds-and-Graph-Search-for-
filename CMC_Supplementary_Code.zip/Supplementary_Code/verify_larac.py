"""Re-plan every main-benchmark instance with the exact feasibility test; compare to stored results."""
import numpy as np, pandas as pd, json
from multiprocessing import Pool
from acp import *
from maps import FAMILIES
N = 64; S, GOAL = 2 * N + 2, (N - 3) * N + (N - 3)
def job(a):
    fam, ker, ell, seed = a
    M = MapModel(FAMILIES[fam](N, np.random.default_rng(seed)), 1.0, GRF(N, ell, kernel=ker))
    out = []
    for d in [0.05, 0.10, 0.20]:
        for m in ["THR50", "THRd", "BOOLE", "IND", "PBFIX", "PB", "CHAIN"]:
            r, _ = plan(M, m, S, GOAL, d)
            out.append(dict(fam=fam, ker=ker, ell=ell, seed=seed, delta=d, method=m, f2=r is not None, L2=None if r is None else r["L"]))
    return out
if __name__ == "__main__":
    df = pd.read_json("results_main.jsonl", lines=True)
    args = df[["fam", "ker", "ell", "seed"]].drop_duplicates().values.tolist()
    with Pool(2) as P: res = [x for o in P.imap_unordered(job, [tuple(a) for a in args], chunksize=4) for x in o]
    R = pd.DataFrame(res).merge(df, on=["fam", "ker", "ell", "seed", "delta", "method"])
    fd = (R.f2 != R.feasible).sum()
    both = R[R.f2 & R.feasible]; ld = (np.abs(both.L2 - both.L) > 1e-9).sum()
    print("instances", len(R), "feasibility disagreements", fd, "length disagreements", ld)
    json.dump(dict(n=len(R), fd=int(fd), ld=int(ld)), open("verify_larac.json", "w"))
