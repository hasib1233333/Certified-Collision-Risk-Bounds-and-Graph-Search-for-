"""Procedural latent-mean fields for two benchmark families (clutter, office)."""
import numpy as np

M_FREE, M_OCC = -3.7, 3.0


def _blob(n, ci, cj, r, A):
    I, J = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
    return A * np.exp(-((I - ci) ** 2 + (J - cj) ** 2) / (2 * r ** 2))


def clutter(n, rng):
    m = np.full((n, n), M_FREE)
    occ = np.zeros((n, n), bool)
    for _ in range(rng.integers(6, 11)):  # certain obstacles
        h, w = rng.integers(3, 10, 2)
        i, j = rng.integers(0, n - h), rng.integers(0, n - w)
        occ[i:i + h, j:j + w] = True
    for _ in range(rng.integers(18, 29)):  # uncertain clutter blobs
        r = rng.uniform(3.0, 8.0)
        peak = rng.uniform(-2.6, -0.3)
        m = np.maximum(m, M_FREE + _blob(n, rng.uniform(0, n), rng.uniform(0, n), r, peak - M_FREE))
    m[occ] = M_OCC
    return _clear_corners(m)


def office(n, rng, room=21, door=3):
    m = np.full((n, n), M_FREE)
    walls = np.zeros((n, n), bool)
    for k in range(room, n - 1, room):
        walls[k - 1:k + 1, :] = True
        walls[:, k - 1:k + 1] = True
    nr = n // room
    # doors on every interior wall segment, each with an uncertain open/closed latent mean
    for a in range(nr):
        for b in range(1, nr):
            k = b * room
            off = rng.integers(3, room - door - 3)
            sl = slice(a * room + off, a * room + off + door)
            walls[k - 1:k + 1, sl] = False
            m[k - 1:k + 1, sl] = rng.choice([M_FREE, rng.uniform(-2.6, -0.5)], p=[0.4, 0.6])
            off = rng.integers(3, room - door - 3)
            sl = slice(a * room + off, a * room + off + door)
            walls[sl, k - 1:k + 1] = False
            m[sl, k - 1:k + 1] = rng.choice([M_FREE, rng.uniform(-2.6, -0.5)], p=[0.4, 0.6])
    for _ in range(rng.integers(8, 15)):  # uncertain furniture
        r = rng.uniform(2.0, 5.0)
        peak = rng.uniform(-2.6, -0.3)
        m = np.maximum(m, M_FREE + _blob(n, rng.uniform(0, n), rng.uniform(0, n), r, peak - M_FREE))
    m[walls] = M_OCC
    return _clear_corners(m)


def _clear_corners(m):
    n = m.shape[0]
    m[:5, :5] = M_FREE
    m[-5:, -5:] = M_FREE
    return m


FAMILIES = dict(clutter=clutter, office=office)
