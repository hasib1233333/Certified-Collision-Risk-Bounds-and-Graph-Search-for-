"""Real-map benchmark: Willow Garage SLAM occupancy map (ROS navigation_tutorials, 0.05 m/px),
downsampled to 0.20 m cells. Grey level g -> occupancy probability via the ROS map_server convention
p=(255-g)/255, with measured-free cells (g>=250) set to p=1e-4 and unknown cells (g=205) kept at p=0.196.
Latent dependence is not stored in the map and is modelled by SE / CAR priors."""
import numpy as np, json, time, sys
from PIL import Image
from scipy.special import ndtri
from multiprocessing import Pool
from acp import *
W = 96; DS = 4
METHODS = ["THR50", "THRd", "BOOLE", "IND", "PB", "CHAIN"]
DELTAS = [0.05, 0.10, 0.20]
SETTINGS = [("se", 2.0), ("se", 4.0), ("car", 16.0)]

PU = 0.05  # prior occupancy of unexplored space (grey level 205)


def load():
    g = np.array(Image.open("data/willow-full-0.05.pgm")).astype(float)
    p = (255 - g) / 255.0              # ROS map_server convention
    p[g >= 250] = 1e-4                 # measured free
    p[g == 205] = PU                   # unexplored
    H, Wd = (g.shape[0] // DS) * DS, (g.shape[1] // DS) * DS
    blk = lambda a: a[:H, :Wd].reshape(H // DS, DS, Wd // DS, DS)
    q = blk(p).mean(axis=(1, 3))
    q[blk(p > 0.65).any(axis=(1, 3))] = 0.999   # any wall pixel -> occupied cell (keeps thin walls)
    return np.clip(q, 1e-4, 1 - 1e-4)


P = load()

def instances(k, rng):
    out = []
    while len(out) < k:
        i, j = rng.integers(0, P.shape[0] - W), rng.integers(0, P.shape[1] - W)
        win = P[i:i + W, j:j + W]
        free = np.argwhere(win <= 1e-4 + 1e-12)
        if len(free) < 500 or ((win > 0.01) & (win < 0.5)).mean() < 0.05:
            continue
        a, b = free[rng.integers(len(free))], free[rng.integers(len(free))]
        if np.hypot(*(a - b)) < 60:
            continue
        M = MapModel(ndtri(win), 1.0, GRF(W, 1.0))
        r, _ = plan(M, "THR50", a[0] * W + a[1], b[0] * W + b[1], 0.1)
        if r is None:
            continue
        out.append((int(i), int(j), int(a[0] * W + a[1]), int(b[0] * W + b[1])))
    return out

def job(arg):
    k, (i, j, s, g), ker, ell = arg
    win = P[i:i + W, j:j + W]
    M = MapModel(ndtri(win), 1.0, GRF(W, ell, kernel=ker))
    recs, paths = [], []
    for d in DELTAS:
        for m in METHODS:
            t0 = time.perf_counter(); r, it = plan(M, m, s, g, d); dt = time.perf_counter() - t0
            rec = dict(inst=k, i=i, j=j, ker=ker, ell=ell, delta=d, method=m, time=dt, feasible=r is not None)
            if r is not None:
                rec.update(L=r["L"], LB=r.get("LB", r["L"]))
                rec.update({"cert_" + c: v for c, v in certificates(M, r["cells"]).items()})
            recs.append(rec); paths.append(None if r is None else r["cells"])
    tr = mc_risk(M, paths, 10000, np.random.default_rng(500 + k))
    for rec, x in zip(recs, tr):
        rec["mc"] = float(x) if rec["feasible"] else None
    return recs

if __name__ == "__main__":
    K = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    inst = instances(K, np.random.default_rng(2026))
    json.dump(inst, open("willow_instances.json", "w"))
    args = [(k, x, ker, ell) for k, x in enumerate(inst) for ker, ell in SETTINGS]
    with Pool(2) as Pp, open("results_willow.jsonl", "w") as fo:
        for n, recs in enumerate(Pp.imap_unordered(job, args)):
            for r in recs: fo.write(json.dumps(r, default=float) + "\n")
            print(n, len(args), time.strftime("%X"), flush=True)
