"""Footprint experiment: a 3x3-cell square robot (Chebyshev radius 1) on clutter/office maps.
Collision iff any cell covered by the footprint at any path cell is occupied.
Certificates use the cells newly swept by each move (overlap/repeats allowed by Theorem 1);
the chain version conditions each new cell on its neighbour inside the previous footprint (Theorem 2, general parent)."""
import numpy as np, json, time, sys
from multiprocessing import Pool
from scipy.special import log_ndtr
from acp import *
from maps import FAMILIES
N = 64; S, GOAL = 2 * N + 2, (N - 3) * N + (N - 3)
FP = [(a, b) for a in (-1, 0, 1) for b in (-1, 0, 1)]
FPS = set(FP)


def new_offsets(d):
    new = [o for o in FP if (o[0] + d[0], o[1] + d[1]) not in FPS]
    # order so that consecutive offsets are 4-adjacent (a simple path through the swept strip)
    nb = lambda x, y: abs(x[0] - y[0]) + abs(x[1] - y[1]) == 1
    start = [o for o in new if sum(nb(o, q) for q in new) <= 1][0]
    seq = [start]
    while len(seq) < len(new):
        seq.append([q for q in new if q not in seq and nb(seq[-1], q)][0])
    return seq


def build(M, method, delta):
    n = M.n; t = M.t; lp1 = M.logP1
    valid = np.zeros((n, n), bool); valid[1:-1, 1:-1] = True
    I, J = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
    rho = lambda a, b: M.grf_plan.rho(a, b)
    def lP2(ci, cj, di, dj):  # log P(F_c & F_c') for arrays of cells, constant offset
        r = rho(di, dj)
        return np.log(np.maximum(bvn_cdf(t[ci], t[cj], np.full(np.shape(ci[0]), r)), 1e-300))
    src, dst, Ls, Rs = [], [], [], []
    for d in DIRS:
        ui, uj = I[valid], J[valid]; vi, vj = ui + d[0], uj + d[1]
        keep = (vi >= 1) & (vi < n - 1) & (vj >= 1) & (vj < n - 1)
        ui, uj, vi, vj = ui[keep], uj[keep], vi[keep], vj[keep]
        offs = new_offsets(d)
        R = np.zeros(len(ui))
        if method == "THRinf":
            R[:] = 0.0
        elif method == "INDfp":
            for o in offs: R -= lp1[vi + o[0], vj + o[1]]
        elif method == "PBfp":
            k = 0
            while k < len(offs):
                a = offs[k]
                if k + 1 < len(offs):
                    b = offs[k + 1]
                    R -= lP2((vi + a[0], vj + a[1]), (vi + b[0], vj + b[1]), b[0] - a[0], b[1] - a[1]); k += 2
                else:
                    R -= lp1[vi + a[0], vj + a[1]]; k += 1
        elif method == "CHfp":
            for o in offs:  # parent: same offset in the previous footprint (cell c - d, lag d)
                c = (vi + o[0], vj + o[1]); p = (vi + o[0] - d[0], vj + o[1] - d[1])
                R -= lP2(c, p, d[0], d[1]) - lp1[p]  # -log P(F_c | F_p) >= 0
            R = np.maximum(R, 0.0)
        src.append(ui * n + uj); dst.append(vi * n + vj); Ls.append(np.full(len(ui), SQ2 if d[0] and d[1] else 1.0)); Rs.append(R)
    s, d_, L, R = map(np.concatenate, (src, dst, Ls, Rs))
    if method == "THRinf":  # binary map inflated by the footprint
        occ = M.p > 0.5
        infl = np.zeros_like(occ)
        for a, b in FP: infl |= np.roll(np.roll(occ, a, 0), b, 1)
        okc = ~infl.ravel(); keep = okc[s] & okc[d_]
        s, d_, L, R = s[keep], d_[keep], L[keep], R[keep]
    # initial footprint cost at the start
    si, sj = divmod(S, n)
    cells = [(si + a, sj + b) for a, b in FP]
    if method == "INDfp":
        r0 = -sum(lp1[c] for c in cells)
    elif method == "PBfp":  # rows of 3: pair (left, centre) + right singleton
        r0 = 0.0
        for a in (-1, 0, 1):
            c1, c2, c3 = (si + a, sj - 1), (si + a, sj), (si + a, sj + 1)
            r0 -= float(np.log(bvn_cdf(np.array([t[c1]]), np.array([t[c2]]), np.array([rho(0, 1)]))[0])) + lp1[c3]
    elif method == "CHfp":  # row-major order, parent = left neighbour (or upper neighbour for column -1)
        r0 = -lp1[cells[0]]
        for a, b in FP[1:]:
            c = (si + a, sj + b); p = (si + a, sj + b - 1) if b > -1 else (si + a - 1, sj + b)
            dd = (c[0] - p[0], c[1] - p[1])
            r0 -= float(np.log(bvn_cdf(np.array([t[c]]), np.array([t[p]]), np.array([rho(*dd)]))[0])) - lp1[p]
    else:
        r0 = 0.0
    return Graph(n * n, s, d_, L, R, S, np.array([GOAL]), r0, -np.log1p(-delta), lambda path: np.asarray(path))


def fp_cells(cells, n):
    """Cells covered by the footprint along the path; second value is True if the footprint leaves the map
    (the map border is treated as a wall, i.e., a certain collision)."""
    cells = np.asarray(cells); out = set(); outside = False
    r, c = cells // n, cells % n
    for a, b in FP:
        rr, cc = r + a, c + b
        ok = (rr >= 0) & (rr < n) & (cc >= 0) & (cc < n)
        outside |= bool((~ok).any())
        out.update((rr[ok] * n + cc[ok]).tolist())
    return np.array(sorted(out)), outside


def job(arg):
    fam, ker, ell, seed = arg
    M = MapModel(FAMILIES[fam](N, np.random.default_rng(seed)), 1.0, GRF(N, ell, kernel=ker))
    recs, paths, flags = [], [], []
    for delta in (0.10, 0.20):
        for m in ("THRinf", "INDpt", "INDfp", "PBfp", "CHfp"):
            t0 = time.perf_counter()
            if m == "INDpt":
                r, _ = plan(M, "IND", S, GOAL, delta)
            else:
                G = build(M, m, delta)
                r = G.solve(1.0, 0.0) if m == "THRinf" else larac(G)[0]
            dt = time.perf_counter() - t0
            rec = dict(fam=fam, ker=ker, ell=ell, seed=seed, delta=delta, method=m, time=dt, feasible=r is not None)
            if r is not None:
                rec["L"] = r["L"]
                if m in ("INDfp", "PBfp", "CHfp"): rec["certR"] = 1 - np.exp(-r["R"])
            if r is None:
                paths.append(None); flags.append(False)
            else:
                c, o = fp_cells(r["cells"], N); paths.append(c); flags.append(o); rec["leaves_map"] = o
            recs.append(rec)
    tr = mc_risk(M, paths, 10000, np.random.default_rng(70_000 + seed))
    for rec, x, o in zip(recs, tr, flags):
        rec["mc"] = (1.0 if o else float(x)) if rec["feasible"] else None
    return recs


if __name__ == "__main__":
    K = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    args = [(f, k, l, s) for f in FAMILIES for (k, l) in (("se", 4.0), ("car", 64.0)) for s in range(K)]
    with Pool(2) as P, open("results_footprint.jsonl", "w") as fo:
        for i, recs in enumerate(P.imap_unordered(job, args)):
            for r in recs: fo.write(json.dumps(r, default=float) + "\n")
            print(i, len(args), time.strftime("%X"), flush=True)
