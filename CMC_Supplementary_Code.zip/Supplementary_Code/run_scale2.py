"""Scalability: grid sizes 64..512, 10 clutter maps each, SE l=2, delta=0.10. Each (n, seed, method)
runs in a fresh process so that peak resident memory (ru_maxrss) is attributable."""
import json, subprocess, sys, time
CHILD = r'''
import json, resource, sys, time, numpy as np
from acp import *; from maps import FAMILIES
n, seed, m = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
rss0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
t0 = time.perf_counter(); M = MapModel(FAMILIES["clutter"](n, np.random.default_rng(seed)), 1.0, GRF(n, 2.0)); tb = time.perf_counter() - t0
rss1 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
t0 = time.perf_counter(); r, it = plan(M, m, 2 * n + 2, (n - 3) * n + (n - 3), 0.10); tp = time.perf_counter() - t0
rss2 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(json.dumps(dict(n=n, seed=seed, method=m, build=tb, time=tp, iters=it, feasible=r is not None,
      rss_build_mb=(rss1 - rss0) / 1024, rss_plan_mb=(rss2 - rss1) / 1024, rss_peak_mb=rss2 / 1024)))
'''
out = open("results_scale2.jsonl", "w")
for n in (64, 128, 256, 512):
    for seed in range(10):
        for m in ("BOOLE", "IND", "PB", "CHAIN"):
            res = subprocess.run([sys.executable, "-c", CHILD, str(n), str(seed), m], capture_output=True, text=True)
            out.write(res.stdout.strip().splitlines()[-1] + "\n"); out.flush()
    print("n", n, "done", time.strftime("%X"), flush=True)
