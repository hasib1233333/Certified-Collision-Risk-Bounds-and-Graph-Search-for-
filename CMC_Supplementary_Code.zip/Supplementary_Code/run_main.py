"""Main benchmark: families x priors x correlation lengths x risk budgets x methods."""
import numpy as np, json, time, sys
from multiprocessing import Pool
from acp import *
from maps import FAMILIES
N = 64; S, GOAL = 2 * N + 2, (N - 3) * N + (N - 3)
METHODS = ["THR50", "THRd", "BOOLE", "IND", "PBFIX", "PB", "CHAIN"]
DELTAS = [0.05, 0.10, 0.20]
SETTINGS = [("se", 0)] + [("se", l) for l in (1, 2, 4)] + [("car", l) for l in (4, 16, 64)]
NMAPS, NMC = (int(sys.argv[1]), int(sys.argv[2])) if len(sys.argv) > 2 else (2, 10000)

def job(arg):
    fam, ker, ell, seed = arg
    g = GRF(N, ell, kernel=ker)
    M = MapModel(FAMILIES[fam](N, np.random.default_rng(seed)), 1.0, g)
    recs, paths = [], []
    for d in DELTAS:
        for m in METHODS:
            t0 = time.perf_counter(); r, it = plan(M, m, S, GOAL, d); dt = time.perf_counter() - t0
            rec = dict(fam=fam, ker=ker, ell=ell, seed=seed, delta=d, method=m, time=dt, iters=it,
                       feasible=r is not None)
            if r is not None:
                rec.update(L=r["L"], LB=r.get("LB", r["L"]), ncell=len(r["cells"]))
                rec.update({"cert_" + k: v for k, v in certificates(M, r["cells"]).items()})
            recs.append(rec); paths.append(None if r is None else r["cells"])
    tr = mc_risk(M, paths, NMC, np.random.default_rng(10_000 + seed))
    for rec, x in zip(recs, tr):
        rec["mc"] = float(x) if rec["feasible"] else None
    return recs

if __name__ == "__main__":
    args = [(f, k, l, s) for f in FAMILIES for (k, l) in SETTINGS for s in range(NMAPS)]
    with Pool(2) as P, open("results_main.jsonl", "w") as fo:
        for i, recs in enumerate(P.imap_unordered(job, args, chunksize=2)):
            for r in recs: fo.write(json.dumps(r, default=float) + "\n")
            if i % 50 == 0: print(i, len(args), time.strftime("%X"), flush=True)
