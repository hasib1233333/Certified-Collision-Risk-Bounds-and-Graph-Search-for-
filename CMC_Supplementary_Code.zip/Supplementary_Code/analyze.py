"""Analysis: tables (LaTeX), figures (grayscale PDF), and numeric macros for the manuscript."""
import json, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon, binomtest, beta
from acp import GRF

OUT = "../CMC_LaTeX_submission/"
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Liberation Sans", "Arial", "Helvetica", "DejaVu Sans"],
                     "font.size": 8, "axes.linewidth": 0.6, "lines.linewidth": 1.0, "lines.markersize": 3.5,
                     "legend.fontsize": 8, "legend.frameon": False, "xtick.direction": "in", "ytick.direction": "in",
                     "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black", "text.color": "black",
                     "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
                     "mathtext.bf": "Liberation Sans:bold", "mathtext.cal": "Liberation Sans:italic", "pdf.fonttype": 42})
PANEL = lambda ax, k: ax.text(-0.1, 1.06, "ABCDEF"[k], transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")
MK = dict(BOOLE=("s", ":", "0.55"), IND=("o", "--", "0.35"), PBFIX=("v", "-.", "0.5"), PB=("^", "-", "0.15"),
          CHAIN=("D", "-", "0.0"), THR50=("x", ":", "0.6"), THRd=("+", ":", "0.6"))
NAME = dict(THR50="THR-0.5", THRd=r"THR-$\delta$", BOOLE="Boole", IND="IND", PBFIX="PB-fix", PB="ACP-PB", CHAIN="ACP-CH")
macros = {}


DIG = dict(zip("0123456789", ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]))


def mac(k, v):
    macros["".join(DIG.get(ch, ch) for ch in k.replace(".", ""))] = v


def cp_upper(k, n, a=0.05):
    return 1.0 if k == n else beta.ppf(1 - a / 2, k + 1, n - k)


def sci(x, d=2):
    """IEEE-style scientific notation a.bc x 10^{e}."""
    if x == 0:
        return "0"
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    if e == 0:
        return f"{x:.{d}f}"
    return rf"{m:.{d}f}\times10^{{{e}}}"


df = pd.read_json("results_main.jsonl", lines=True)
# ground-truth risk: exact for the independent regime (product formula), Monte Carlo otherwise
df["exact"] = df["ell"] == 0
df["risk"] = np.where(df["exact"], 1 - df["cert_IND"], df["mc"])
se = np.sqrt(df["delta"] * (1 - df["delta"]) / 1e4)
df["viol"] = np.where(df["exact"], df["risk"] > df["delta"] + 1e-12, df["mc"] > df["delta"] + 3 * se)
df["rawexc"] = df["mc"] > df["delta"]
df["setting"] = df["ker"] + df["ell"].astype(str)
rho1 = {}
for k, l in df[["ker", "ell"]].drop_duplicates().values:
    rho1[(k, l)] = GRF(64, l, kernel=k).rho(0, 1) if l > 0 else 0.0
df["rho1"] = [rho1[(k, l)] for k, l in zip(df.ker, df.ell)]
CERT = ["BOOLE", "IND", "PB", "CHAIN"]
mac("Nplans", f"{len(df):,}".replace(",", "{,}"))
for m in ["BOOLE", "IND", "PB", "PBFIX", "CHAIN"]:
    sub = df[(df.method == m) & df.feasible & (df.ell > 0)]
    mac(f"rawexc{m}", str(int(sub.rawexc.sum())))
    mac(f"rawmax{m}", f"{(sub.mc / sub.delta).max():.3f}")
mac("rawexcCHse", str(int(df[(df.method == "CHAIN") & df.feasible & (df.ker == "se") & (df.ell > 0)].rawexc.sum())))
mac("Nmaps", str(df.groupby(["fam", "ker", "ell", "seed"]).ngroups))

# ---------------------------------------------------------------- safety summary
saf = df[df.feasible].groupby(["method", "ker"]).agg(n=("viol", "size"), v=("viol", "sum")).reset_index()
print(saf)
for m in ["BOOLE", "IND", "PB", "PBFIX"]:
    sub = df[(df.method == m) & df.feasible & ((df.ker == "car") | (df.ell == 0) | (m != "CHAIN"))]
    mac(f"viol{m}", str(int(sub.viol.sum()))); mac(f"n{m}", f"{len(sub):,}".replace(",", "{,}"))
    mac(f"cpu{m}", sci(cp_upper(int(sub.viol.sum()), len(sub))))
for k in ["se", "car"]:
    sub = df[(df.method == "CHAIN") & df.feasible & (df.ker == k) & (df.ell > 0)]
    mac(f"violCH{k}", str(int(sub.viol.sum()))); mac(f"nCH{k}", f"{len(sub):,}".replace(",", "{,}"))
    mac(f"maxexCH{k}", f"{(sub.mc / sub.delta).max():.3f}")
for m in ["THR50", "THRd"]:
    sub = df[(df.method == m) & df.feasible]
    mac(f"violrate{m}", f"{100 * sub.viol.mean():.1f}")
# slack of certificates
for m in CERT:
    sub = df[(df.method == m) & df.feasible]
    mac(f"maxratio{m}", f"{(sub.mc / sub.delta).max():.3f}")

# ---------------------------------------------------------------- main table (delta = 0.10)
d0 = 0.10
rows = []
settings = [("se", 0.0), ("se", 1.0), ("se", 2.0), ("se", 4.0), ("car", 4.0), ("car", 16.0), ("car", 64.0)]
for fam in ["clutter", "office"]:
    for k, l in settings:
        sub = df[(df.fam == fam) & (df.ker == k) & (df.ell == l) & (df.delta == d0)]
        piv = sub.pivot(index="seed", columns="method")
        feas = piv["feasible"].mean() * 100
        common = piv["feasible"][CERT].all(axis=1)
        Ls = piv["L"][common]
        viol = {m: (piv["viol"][m][piv["feasible"][m]]).mean() * 100 for m in ["THR50", "THRd"]}
        vc = sum(int(piv["viol"][m][piv["feasible"][m]].sum()) for m in ["BOOLE", "IND", "PB"])
        rows.append(dict(fam=fam, ker=k, ell=l, rho=rho1[(k, l)], fB=feas["BOOLE"], fI=feas["IND"], fP=feas["PB"],
                         fC=feas["CHAIN"], LI=Ls["IND"].mean(), LP=Ls["PB"].mean(), LC=Ls["CHAIN"].mean(),
                         ncom=int(common.sum()), v50=viol["THR50"], vd=viol["THRd"], vcert=vc,
                         vch=int(piv["viol"]["CHAIN"][piv["feasible"]["CHAIN"]].sum())))
T = pd.DataFrame(rows)
print(T.round(2).to_string())
lines = []
for fam in ["clutter", "office"]:
    lines.append(r"\multicolumn{14}{l}{\textit{" + fam.capitalize() + r" family}}\\")
    for _, r in T[T.fam == fam].iterrows():
        prior = "indep." if r.ell == 0 else (rf"SE, $\ell={r.ell:g}$" if r.ker == "se" else rf"CAR, $\ell={r.ell:g}$")
        best = max(r.fB, r.fI, r.fP, r.fC)
        f = lambda x: (rf"\textbf{{{x:.1f}}}" if abs(x - best) < 1e-9 else f"{x:.1f}")
        Lmin = min(r.LI, r.LP, r.LC)
        g = lambda x: (rf"\textbf{{{x:.2f}}}" if abs(x - Lmin) < 1e-9 else f"{x:.2f}")
        lines.append(rf"{prior} & {r.rho:.2f} & {f(r.fB)} & {f(r.fI)} & {f(r.fP)} & {f(r.fC)} & {r.ncom} & {g(r.LI)} & {g(r.LP)} & {g(r.LC)}"
                     rf" & {r.v50:.1f} & {r.vd:.1f} & {r.vcert} & {r.vch}\\")
open(OUT + "tab_main.tex", "w").write("\n".join(lines))

# headline numbers: feasibility gains at the strongest correlation
for fam in ["clutter", "office"]:
    r = T[(T.fam == fam) & (T.ker == "se") & (T.ell == 4)].iloc[0]
    mac(f"fI{fam}", f"{r.fI:.1f}"); mac(f"fP{fam}", f"{r.fP:.1f}"); mac(f"fC{fam}", f"{r.fC:.1f}")
    mac(f"fB{fam}", f"{r.fB:.1f}")

# ---------------------------------------------------------------- all deltas: feasibility (pooled)
agg = df[df.ell > 0].groupby(["delta", "method"]).feasible.mean().unstack() * 100
print(agg.round(1))
for d in [0.05, 0.1, 0.2]:
    for m in CERT:
        mac(f"feas{m}d{int(d * 100)}", f"{agg.loc[d, m]:.1f}")

# ---------------------------------------------------------------- statistics: paired tests, Holm
tests = []
corr = df[df.ell > 0]
key = ["fam", "ker", "ell", "seed", "delta"]
W = corr.pivot_table(index=key, columns="method", values=["L", "feasible"], aggfunc="first")
pairs = [("PB", "IND"), ("CHAIN", "PB"), ("CHAIN", "IND"), ("IND", "BOOLE"), ("PB", "PBFIX")]
for a, b in pairs:
    both = W["feasible"][a].astype(bool) & W["feasible"][b].astype(bool)
    x, y = W["L"][a][both].astype(float), W["L"][b][both].astype(float)
    dlt = (x - y).values
    nz = dlt[np.abs(dlt) > 1e-9]
    p_w = wilcoxon(nz).pvalue if len(nz) > 0 else 1.0
    fa, fb = W["feasible"][a].astype(bool), W["feasible"][b].astype(bool)
    n10, n01 = int((fa & ~fb).sum()), int((~fa & fb).sum())
    p_m = binomtest(n10, n10 + n01, 0.5).pvalue if n10 + n01 > 0 else 1.0
    rng = np.random.default_rng(0)
    bs = [rng.choice(dlt, len(dlt)).mean() for _ in range(10000)]
    tests.append(dict(a=a, b=b, n=int(both.sum()), md=dlt.mean(), lo=np.percentile(bs, 2.5), hi=np.percentile(bs, 97.5),
                      nshorter=int((dlt < -1e-9).sum()), nlonger=int((dlt > 1e-9).sum()), pw=p_w, n10=n10, n01=n01, pm=p_m))
TS = pd.DataFrame(tests)
# Holm over the 2*len(pairs) p-values
pv = np.r_[TS.pw.values, TS.pm.values]
order = np.argsort(pv); adj = np.empty_like(pv); run = 0
for rank, i in enumerate(order):
    run = max(run, min(1, (len(pv) - rank) * pv[i])); adj[i] = run
TS["pw_h"], TS["pm_h"] = adj[:len(TS)], adj[len(TS):]
print(TS.to_string())


def pfmt(p):
    return r"$<0.001$" if p < 1e-3 else f"{p:.3f}"


lines = []
for _, r in TS.iterrows():
    lines.append(rf"{NAME[r.a]} vs.\ {NAME[r.b]} & {r.n} & ${sci(r.md) if abs(r.md) < 1e-2 else f'{r.md:.3f}'}$ & $[{r.lo:.3f},\,{r.hi:.3f}]$ & {r.nshorter}/{r.nlonger} & {pfmt(r.pw_h)} & {r.n10}/{r.n01} & {pfmt(r.pm_h)}\\")
open(OUT + "tab_stats.tex", "w").write("\n".join(lines))
r = TS[(TS.a == "PB") & (TS.b == "IND")].iloc[0]
mac("PBINDnten", str(r.n10)); mac("PBINDnzero", str(r.n01)); mac("PBINDshort", str(r.nshorter)); mac("PBINDlong", str(r.nlonger))
r = TS[(TS.a == "CHAIN") & (TS.b == "IND")].iloc[0]
mac("CHINDnten", str(r.n10)); mac("CHINDnzero", str(r.n01))

# ---------------------------------------------------------------- tightness: certified risk / MC risk
rows = []
for m, ck in [("BOOLE", "cert_BOOLE"), ("IND", "cert_IND"), ("PB", "cert_PB"), ("CHAIN", "cert_CHAIN")]:
    sub = df[(df.method == "PB") & df.feasible & (df.ell > 0) & (df.mc > 0.002)]
    ratio = (1 - sub[ck]) / sub.mc
    rows.append((m, ratio.median()))
    mac(f"cons{m}", f"{ratio.median():.2f}")
print("conservatism (median certified/MC risk on ACP-PB paths):", rows)
for k, l in [("se", 4.0), ("car", 64.0)]:
    sub = df[(df.method == "PB") & df.feasible & (df.ker == k) & (df.ell == l) & (df.mc > 0.002)]
    for c in ["IND", "PB", "CHAIN"]:
        mac(f"cons{c}{k}{int(l)}", f"{((1 - sub['cert_' + c]) / sub.mc).median():.2f}")

# ---------------------------------------------------------------- runtime
rt = df[df.ell > 0].groupby("method").time.median() * 1000
it = df[(df.ell > 0) & df.feasible].groupby("method").iters.mean()
for m in rt.index:
    mac(f"time{m}", f"{rt[m]:.1f}")
for m in CERT:
    mac(f"iter{m}", f"{it[m]:.2f}")
gap = df[(df.ell > 0) & df.feasible & df.method.isin(CERT)]
relgap = (gap.L - gap.LB) / gap.L
mac("gapmed", sci(relgap.median()) if relgap.median() > 0 else "0")
mac("gapmean", f"{100 * relgap.mean():.2f}")
mac("gapp95", f"{100 * np.percentile(relgap, 95):.2f}")
mac("gapzero", f"{100 * (relgap < 1e-9).mean():.1f}")

# ---------------------------------------------------------------- figure: feasibility & length vs rho
fig, ax = plt.subplots(1, 2, figsize=(6.4, 2.6))
for j, fam in enumerate(["clutter", "office"]):
    sub = df[(df.fam == fam) & (df.delta == d0)]
    for m in ["BOOLE", "IND", "PBFIX", "PB", "CHAIN"]:
        for k, ls in [("se", "-"), ("car", "--")]:
            s2 = sub[(sub.method == m) & ((sub.ker == k) | (sub.ell == 0))]
            g = s2.groupby("rho1").feasible.mean() * 100
            mk, _, c = MK[m]
            ax[j].plot(g.index, g.values, marker=mk, ls=ls, color=c, mfc="white" if k == "car" else c,
                       label=(NAME[m] if k == "se" else None))
    ax[j].set_xlabel(r"Lag-one latent correlation $\Sigma_{uv}$")
    PANEL(ax[j], j)
    ax[j].grid(alpha=0.25, lw=0.4)
ax[0].set_ylabel("Certified feasibility (%)")
fig.tight_layout(rect=(0, 0.16, 1, 1))
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=5, bbox_to_anchor=(0.5, 0.04))
fig.text(0.5, -0.02, "Solid lines, filled markers: SE prior.   Dashed lines, hollow markers: CAR (GMRF) prior.", ha="center", fontsize=8)
fig.savefig(OUT + "figs/fig_feas.pdf", bbox_inches="tight"); plt.close(fig)

# ---------------------------------------------------------------- figure: certificate tightness scatter
fig, ax = plt.subplots(1, 2, figsize=(6.4, 2.9))
for j, (k, l) in enumerate([("se", 4.0), ("car", 64.0)]):
    sub = df[(df.method == "PB") & df.feasible & (df.ker == k) & (df.ell == l) & (df.mc > 1e-3)]
    for c, mk, col in [("BOOLE", "s", "0.65"), ("IND", "o", "0.45"), ("PB", "^", "0.2"), ("CHAIN", "D", "0.0")]:
        ax[j].scatter(sub.mc, 1 - sub["cert_" + c].clip(upper=1 - 1e-12), s=7, marker=mk, facecolor="none",
                      edgecolor=col, lw=0.5, label=NAME[c] + " certificate")
    lim = [1e-3, 1]
    ax[j].plot(lim, lim, "k-", lw=0.6)
    ax[j].set_xscale("log"); ax[j].set_yscale("log"); ax[j].set_xlim(lim); ax[j].set_ylim(lim)
    ax[j].set_xlabel("Monte Carlo collision probability")
    PANEL(ax[j], j)
    ax[j].grid(alpha=0.25, lw=0.4, which="major")
ax[0].set_ylabel("Certified upper bound on risk")
fig.tight_layout(rect=(0, 0.1, 1, 1))
h, l = ax[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=4, markerscale=1.5, bbox_to_anchor=(0.5, 0.0))
fig.savefig(OUT + "figs/fig_tight.pdf", bbox_inches="tight"); plt.close(fig)

# ---------------------------------------------------------------- figure: per-delta feasibility bars
fig, ax = plt.subplots(figsize=(3.4, 2.4))
w = 0.2
for i, m in enumerate(CERT):
    vals = [agg.loc[d, m] for d in [0.05, 0.1, 0.2]]
    ax.bar(np.arange(3) + (i - 1.5) * w, vals, w, color=["0.85", "0.6", "0.35", "0.1"][i], edgecolor="k", lw=0.4,
           label=NAME[m], hatch=["", "///", "", ""][i])
ax.set_xticks(range(3)); ax.set_xticklabels([r"$\delta=0.05$", r"$\delta=0.10$", r"$\delta=0.20$"])
ax.set_ylabel("Certified feasibility (%)"); ax.set_ylim(0, 100)
ax.legend(ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.13), handlelength=1.2, columnspacing=0.8)
ax.grid(axis="y", alpha=0.25, lw=0.4)
fig.tight_layout(); fig.savefig(OUT + "figs/fig_delta.pdf", bbox_inches="tight"); plt.close(fig)

with open(OUT + "numbers.tex", "w") as f:
    for k, v in macros.items():
        f.write(rf"\newcommand{{\{k}}}{{{v}}}" + "\n")
print(macros)
