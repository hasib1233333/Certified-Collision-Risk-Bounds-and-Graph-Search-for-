#!/usr/bin/env bash
# Regenerates every table, figure and number of the manuscript (about 2 h on 2 CPU cores).
# Outputs are written to the manuscript folder set by OUT in analyze*.py (default ../manuscript/).
set -euo pipefail
cd "$(dirname "$0")"
python3 run_main.py 60 10000                                          # 840 maps x 3 budgets x 7 planners
python3 verify_larac.py                                               # exact-feasibility re-planning check
python3 run_abl.py                                                    # misspecification, negative correlation
python3 run_gmrf.py 30                                                # GMRF pipeline, prior weight 0.35
WPRIOR=0.7 GOUT=results_gmrf_w07.jsonl python3 run_gmrf.py 30         # calibration, prior weight 0.70
WPRIOR=1.0 GOUT=results_gmrf_w10.jsonl python3 run_gmrf.py 30         # calibration, correct prior
python3 run_willow.py 40                                              # Willow Garage real map
python3 run_footprint.py 30                                           # 3x3 footprint robot
python3 run_scale2.py                                                 # scalability 64^2..512^2 with memory
python3 analyze.py; python3 analyze_abl.py; python3 analyze_willow.py; python3 analyze_new.py; python3 fig_example.py
