"""GMRF occupancy-mapping pipeline: prior Q = (kappa^2 I + Lap)/s (M-matrix), noisy per-cell observations,
non-stationary posterior; planners use posterior marginals and posterior neighbour correlations."""
import numpy as np, json, time, sys
import scipy.sparse as sp
from scipy.linalg import cholesky, solve_triangular, cho_solve
from multiprocessing import Pool
from acp import *
from maps import FAMILIES
N = 64; S, GOAL = 2 * N + 2, (N - 3) * N + (N - 3)
WPRIOR = float(__import__('os').environ.get('WPRIOR', '0.35'))
KAPPA = 1 / 16.0; SIG_N = 1.0; MU0 = -2.0; COV = 0.5
METHODS = ["THR50", "THRd", "BOOLE", "IND", "PB", "CHAIN"]
DELTAS = [0.05, 0.10, 0.20]

def lap(n):
    I = sp.identity(n); D = sp.diags([-1.0, 2.0, -1.0], [-1, 0, 1], (n, n)).tolil(); D[0, 0] = D[-1, -1] = 1
    return (sp.kron(D, I) + sp.kron(I, D)).tocsc()

Q0 = (KAPPA ** 2 * sp.identity(N * N) + lap(N)).toarray()
s0 = np.sqrt(np.diag(np.linalg.inv(Q0)).mean())
Q0 = Q0 * s0 ** 2 * 1.5 ** 2 / 1.0   # prior marginal sd ~ 1.5 (scale only, M-matrix kept)

def job(arg):
    fam, seed = arg
    rng = np.random.default_rng(seed)
    env = FAMILIES[fam](N, rng).ravel()                 # environment structure (latent)
    Lp = cholesky(Q0, lower=True)
    ztrue = env + solve_triangular(Lp.T, rng.standard_normal(N * N), lower=False)  # true latent
    blk = rng.random((N // 16, N // 16)) < 0.5            # explored 16x16 regions (others unexplored)
    obs = (np.kron(blk, np.ones((16, 16))).ravel() > 0) & (rng.random(N * N) < COV)
    D = obs / SIG_N ** 2
    Qp = Q0 + np.diag(D)                                 # posterior precision: still an M-matrix
    Lq = cholesky(Qp, lower=True)
    y = np.where(obs, ztrue + SIG_N * rng.standard_normal(N * N), 0.0)
    prior_mean = MU0 + WPRIOR * (env - MU0)              # structural prior; WPRIOR=1 is correctly specified
    mpost = cho_solve((Lq, True), Q0 @ prior_mean + D * y)
    C = cho_solve((Lq, True), np.eye(N * N))
    sd = np.sqrt(np.diag(C))
    mincov = C.min()
    corr = lambda u, v, di, dj: C[u, v] / (sd[u] * sd[v])
    def sampler(m, rg):
        X = solve_triangular(Lq.T, rg.standard_normal((N * N, m)), lower=False)
        return (X / sd[:, None]).T.reshape(m, N, N)
    M = MapModel(mpost.reshape(N, N), sd.reshape(N, N), corr=corr, sampler=sampler)
    recs, paths = [], []
    for d in DELTAS:
        for m in METHODS:
            t0 = time.perf_counter(); r, it = plan(M, m, S, GOAL, d); dt = time.perf_counter() - t0
            rec = dict(fam=fam, seed=seed, delta=d, method=m, time=dt, feasible=r is not None, mincov=float(mincov), wprior=WPRIOR)
            if r is not None:
                rec.update(L=r["L"], LB=r.get("LB", r["L"]))
                rec.update({"cert_" + k: v for k, v in certificates(M, r["cells"]).items()})
                rec["real_collision"] = bool(np.any(ztrue[np.unique(r["cells"])] > 0))
            recs.append(rec); paths.append(None if r is None else r["cells"])
    tr = mc_risk(M, paths, 6000, np.random.default_rng(seed + 31337), batch=1000)
    for rec, x in zip(recs, tr):
        rec["mc"] = float(x) if rec["feasible"] else None
    return recs

if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    with Pool(2) as P, open(__import__("os").environ.get("GOUT", "results_gmrf.jsonl"), "w") as fo:
        for i, recs in enumerate(P.imap_unordered(job, [(f, s) for f in FAMILIES for s in range(n)])):
            for r in recs: fo.write(json.dumps(r, default=float) + "\n")
            print(i, time.strftime("%X"), flush=True)
