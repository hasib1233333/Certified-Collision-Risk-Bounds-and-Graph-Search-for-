"""Qualitative example: occupancy map with paths of THR-0.5, IND, ACP-PB, ACP-CH (grayscale)."""
import numpy as np, pandas as pd, matplotlib, json
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from acp import *
from maps import FAMILIES
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Liberation Sans", "Arial", "Helvetica", "DejaVu Sans"],
                     "font.size": 8, "axes.linewidth": 0.6, "lines.linewidth": 1.0, "lines.markersize": 3.5,
                     "legend.fontsize": 8, "legend.frameon": False, "xtick.direction": "in", "ytick.direction": "in",
                     "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black", "text.color": "black",
                     "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
                     "mathtext.bf": "Liberation Sans:bold", "mathtext.cal": "Liberation Sans:italic", "pdf.fonttype": 42})
PANEL = lambda ax, k: ax.text(-0.1, 1.06, "ABCDEF"[k], transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")
def sci(x):
    e = int(np.floor(np.log10(x))); return f"${x / 10 ** e:.2f}\\times10^{{{e}}}$"


N = 64; S, G = 2 * N + 2, (N - 3) * N + (N - 3)
df = pd.read_json("results_main.jsonl", lines=True)
picks = []
for fam in ["clutter", "office"]:
    sub = df[(df.fam == fam) & (df.ker == "se") & (df.ell == 4.0) & (df.delta == 0.10)]
    piv = sub.pivot(index="seed", columns="method", values="feasible")
    Lp = sub.pivot(index="seed", columns="method", values="L")
    cand = piv[(~piv["IND"].astype(bool)) & piv["PB"].astype(bool) & piv["CHAIN"].astype(bool)].index.tolist()
    if not cand:
        d = (Lp["IND"] - Lp["CHAIN"]).dropna()
        cand = [d.idxmax()]
    picks.append((fam, int(cand[0])))
fig, ax = plt.subplots(1, 2, figsize=(6.4, 4.0))
info = {}
for j, (fam, seed) in enumerate(picks):
    M = MapModel(FAMILIES[fam](N, np.random.default_rng(seed)), 1.0, GRF(N, 4.0))
    img = np.log10(np.clip(M.p, 1e-4, 1))
    ax[j].imshow(img, cmap="Greys", vmin=-4, vmax=0, origin="lower", interpolation="nearest")
    styles = dict(THR50=(":", "0.0", 1.4), IND=("--", "0.0", 1.0), PB=("-", "0.45", 1.6), CHAIN=("-", "0.0", 1.0))
    names = dict(THR50="THR-0.5", IND="IND", PB="ACP-PB", CHAIN="ACP-CH")
    paths = []
    for m in ["THR50", "IND", "PB", "CHAIN"]:
        r, _ = plan(M, m, S, G, 0.10)
        paths.append(None if r is None else r["cells"])
    mc = mc_risk(M, paths, 20000, np.random.default_rng(5))
    for m, cells, x in zip(["THR50", "IND", "PB", "CHAIN"], paths, mc):
        if cells is None:
            ax[j].plot([], [], color="w", label=f"{names[m]}: infeasible")
            info[(fam, m)] = None
            continue
        rr, cc = cells // N, cells % N
        ls, col, lw = styles[m]
        Lm = sum(np.hypot(np.diff(rr), np.diff(cc)))
        ax[j].plot(cc, rr, ls=ls, color=col, lw=lw, label=f"{names[m]}: $L$={Lm:.1f}, $\\mathcal{{R}}$={sci(x)}")
        if col == "0.0" and ls == "-":
            ax[j].plot(cc, rr, ls="-", color="w", lw=0.35)
        info[(fam, m)] = (Lm, x)
    ax[j].plot(2, 2, "ks", ms=4); ax[j].plot(61, 61, "k*", ms=6)
    ax[j].set_xticks([]); ax[j].set_yticks([])
    PANEL(ax[j], j)
    ax[j].legend(loc="upper center", bbox_to_anchor=(0.5, -0.02), ncol=1, frameon=False)
cb = fig.colorbar(ax[1].images[0], ax=ax, fraction=0.025, pad=0.01)
cb.set_label(r"$\log_{10}$ occupancy probability $p_i$", fontsize=8)
fig.savefig("../CMC_LaTeX_submission/figs/fig_example.pdf", bbox_inches="tight")
json.dump({f"{k[0]}-{k[1]}": v for k, v in info.items()} | {"picks": picks}, open("example_info.json", "w"))
print(picks, info)
