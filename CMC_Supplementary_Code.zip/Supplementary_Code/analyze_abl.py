"""Analysis of ablations (misspecification, negative correlation, scaling) and the GMRF mapping pipeline."""
import numpy as np, pandas as pd, matplotlib, matplotlib.ticker
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import beta
OUT = "../CMC_LaTeX_submission/"
plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Liberation Sans", "Arial", "Helvetica", "DejaVu Sans"],
                     "font.size": 8, "axes.linewidth": 0.6, "lines.linewidth": 1.0, "lines.markersize": 3.5,
                     "legend.fontsize": 8, "legend.frameon": False, "xtick.direction": "in", "ytick.direction": "in",
                     "axes.labelcolor": "black", "xtick.color": "black", "ytick.color": "black", "text.color": "black",
                     "mathtext.fontset": "custom", "mathtext.rm": "Liberation Sans", "mathtext.it": "Liberation Sans:italic",
                     "mathtext.bf": "Liberation Sans:bold", "mathtext.cal": "Liberation Sans:italic", "pdf.fonttype": 42})
PANEL = lambda ax, k: ax.text(-0.1, 1.06, "ABCDEF"[k], transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")
DIG = dict(zip("0123456789", ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]))
macros = {}
mac = lambda k, v: macros.__setitem__("".join(DIG.get(c, c) for c in k.replace(".", "")), v)
NAME = dict(BOOLE="Boole", IND="IND", PB="ACP-PB", CHAIN="ACP-CH", THR50="THR-0.5", THRd=r"THR-$\delta$")


def cpu(k, n):
    return 1.0 if k == n else beta.ppf(0.975, k + 1, n - k)


def sci(x, d=2):
    if x == 0: return "0"
    e = int(np.floor(np.log10(abs(x)))); m = x / 10 ** e
    return f"{x:.{d}f}" if e == 0 else rf"{m:.{d}f}\times10^{{{e}}}"


A = pd.read_json("results_abl.jsonl", lines=True)
# ---------------- misspecification
SE10 = 3 * np.sqrt(0.09 / 1e4)
mis = A[A.exp == "mis"].copy(); mis["viol"] = mis.mc > 0.10 + SE10
g = mis.groupby(["ell_plan", "method"]).agg(feas=("feasible", "mean"), nv=("viol", "sum"), n=("feasible", "sum"),
                                              mx=("mc", "max")).reset_index()
print(g)
lines = []
for lp in sorted(mis.ell_plan.unique()):
    row = [f"{lp:g}" + (r" (true)" if lp == 2 else "")]
    for m in ["IND", "PB", "CHAIN"]:
        r = g[(g.ell_plan == lp) & (g.method == m)].iloc[0]
        row += [f"{100 * r.feas:.1f}", f"{int(r.nv)}/{int(r.n)}", f"${sci(r.mx)}$"]
    lines.append(" & ".join(row) + r"\\")
open(OUT + "tab_mis.tex", "w").write("\n".join(lines))
for lp in [3.0, 4.0]:
    for m in ["PB", "CHAIN", "IND"]:
        r = g[(g.ell_plan == lp) & (g.method == m)].iloc[0]
        mac(f"misv{m}{int(lp)}", str(int(r.nv))); mac(f"misn{m}{int(lp)}", str(int(r.n)))
        mac(f"mismx{m}{int(lp)}", f"{r.mx:.3f}")

# ---------------- negative correlation stress test
neg = A[A.exp == "neg"].copy(); neg["viol"] = neg.mc > 0.10 + SE10
mac("negmincov", f"{neg.mincov.iloc[0]:.2f}")
for m in ["BOOLE", "IND", "PB", "CHAIN"]:
    s = neg[(neg.method == m) & neg.feasible]
    mac(f"negv{m}", str(int(s.viol.sum()))); mac(f"negn{m}", str(len(s))); mac(f"negmx{m}", f"{s.mc.max():.3f}")
    # bound violation (certificate below truth) per path, independent of delta
    under = (1 - s["cert_" + m]) < s.mc - 3 * np.sqrt(s.mc * (1 - s.mc) / 1e4)
    mac(f"negunder{m}", str(int(under.sum())))
    print("neg", m, len(s), int(s.viol.sum()), s.mc.max(), "cert<truth:", int(under.sum()))
# certificate validity per path (any method's path) in the negative-correlation regime
allp = neg[neg.feasible]
for c in ["IND", "PB", "CHAIN", "BOOLE"]:
    under = (1 - allp["cert_" + c]) < allp.mc - 3 * np.sqrt(allp.mc * (1 - allp.mc) / 1e4)
    mac(f"neginvalid{c}", str(int(under.sum()))); mac("negnpaths", str(len(allp)))
    print("neg cert", c, "invalid on", int(under.sum()), "of", len(allp))

# ---------------- scaling
sc = A[A.exp == "scale"].copy(); sc["n"] = sc.n.astype(int)
t = sc.groupby(["n", "method"]).time.median().unstack() * 1000
b = sc.groupby("n").build.median() * 1000
print(t, b)
for n in t.index:
    for m in t.columns:
        mac(f"sc{m}{n}", f"{t.loc[n, m]:.0f}")
    mac(f"scbuild{n}", f"{b[n]:.0f}")
fig, ax = plt.subplots(figsize=(3.4, 2.5))
mk = dict(BOOLE=("s", "0.6"), IND=("o", "0.4"), PB=("^", "0.15"), CHAIN=("D", "0.0"))
for m in ["BOOLE", "IND", "PB", "CHAIN"]:
    ax.plot(t.index ** 2, t[m], marker=mk[m][0], color=mk[m][1], label=NAME[m] + " (LARAC)")
ax.plot(b.index ** 2, b.values, "k:", marker="x", label="cost construction")
xs = np.array([64 ** 2, 256 ** 2]); ax.plot(xs, t["PB"].iloc[0] * xs / xs[0], color="0.7", lw=0.6, ls="-.",
                                             label=r"$\propto|V|$ reference")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel(r"Grid size (number of cells $|V|$)")
ax.set_xticks([64 ** 2, 128 ** 2, 256 ** 2]); ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
ax.set_xticklabels([r"$64^2$", r"$128^2$", r"$256^2$"]); ax.set_ylabel("Median time (ms)")
ax.grid(alpha=0.25, lw=0.4, which="both")
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.3), ncol=3, fontsize=6.5, handlelength=1.6, columnspacing=0.8)
fig.tight_layout(); fig.savefig(OUT + "figs/fig_scale.pdf", bbox_inches="tight"); plt.close(fig)

# ---------------- GMRF mapping pipeline
Gm = pd.read_json("results_gmrf.jsonl", lines=True); Gm["viol"] = Gm.mc > Gm.delta + 3 * np.sqrt(Gm.delta * (1 - Gm.delta) / 6000)
Gm["rawexc"] = Gm.mc > Gm.delta
mac("gmrfmaps", str(Gm.groupby(["fam", "seed"]).ngroups)); mac("gmrfmincov", sci(Gm.mincov.min()))
lines = []
for m in ["THR50", "THRd", "BOOLE", "IND", "PB", "CHAIN"]:
    row = [NAME[m]]
    for d in [0.05, 0.10, 0.20]:
        s = Gm[(Gm.method == m) & (Gm.delta == d)]
        f = s.feasible.mean() * 100
        sf = s[s.feasible]
        row += [f"{f:.1f}", f"{int(sf.viol.sum())}", f"${sci(sf.mc.mean())}$" if len(sf) else "--"]
    lines.append(" & ".join(row) + r"\\")
open(OUT + "tab_gmrf.tex", "w").write("\n".join(lines))
for m in ["THR50", "THRd", "BOOLE", "IND", "PB", "CHAIN"]:
    s = Gm[(Gm.method == m) & Gm.feasible]
    mac(f"gv{m}", str(int(s.viol.sum()))); mac(f"gn{m}", str(len(s)))
    if "real_collision" in s:
        mac(f"greal{m}", f"{100 * s.real_collision.astype(float).mean():.1f}")
cert = Gm[Gm.method.isin(["BOOLE", "IND", "PB", "CHAIN"]) & Gm.feasible]
mac("gcertviol", str(int(cert.viol.sum()))); mac("gcertn", str(len(cert))); mac("gcertraw", str(int(cert.rawexc.sum())))
mac("grealcertlo", f"{100 * cert.groupby('method').real_collision.mean().min():.1f}"); mac("grealcerthi", f"{100 * cert.groupby('method').real_collision.mean().max():.1f}")
mac("gcertcpu", sci(cpu(int(cert.viol.sum()), len(cert))))
for m in ["IND", "PB", "CHAIN"]:
    s = Gm[(Gm.method == "CHAIN") & Gm.feasible & (Gm.mc > 1e-3)]
    mac(f"gcons{m}", f"{((1 - s['cert_' + m]) / s.mc).median():.2f}")
print(Gm.groupby(["delta", "method"]).agg(f=("feasible", "mean"), v=("viol", "sum")).unstack())
with open(OUT + "numbers_abl.tex", "w") as f:
    for k, v in macros.items():
        f.write(rf"\newcommand{{\{k}}}{{{v}}}" + "\n")
print(macros)
